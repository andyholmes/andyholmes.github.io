/* Tracker Search Provider for Gnome Shell
 *
 * 2012 Contributors Christian Weber, Felix Schultze, Martyn Russell
 * 2014 Florian Miess
 * 2019 Andy Holmes
 *
 * This programm is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Version 1.5
 *
 * https://github.com/cewee/tracker-search
 *
 *
 * Version 1.6
 * https://github.com/hamiller/tracker-search-provider
 *
 */

const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const St = imports.gi.St;

const Main = imports.ui.main;
const Util = imports.misc.util;


/**
 * Search Result Limit
 *
 * TODO: it sure seems like we only get slots for 5 results
 */
const MAX_RESULTS = 5;


/**
 * Check for the Tracker GIR and send a notification if not found.
 */
var Tracker = null;

function haveTracker() {
    try {
        if (Tracker === null) {
            imports.gi.versions.Tracker = '2.0';
            Tracker = imports.gi.Tracker;
        }
        
        return true;
    } catch (e) {
        Main.notifyError('Tracker Search Provider', e.message);
        return false;
    }
}


/**
 * Tracker Search Provider
 */
class TrackerSearchProvider {
    
    constructor(params) {
        this.resultsMap = new Map();
    }
    
    get appInfo() {
        if (this._appInfo === undefined) {
            this._appIcon = new Gio.ThemedIcon({name: 'system-search'});
            this._appInfo = {
                get_name: () => 'Tracker',
                get_icon: () => this._appIcon,
                get_id: () => this.id
            };
        }
        
        return this._appInfo;
    }
    
    get canLaunchSearch() {
        // TODO: Is there actually a GUI for tracker anymore?
        return false;
    }
    
    get id() {
        // TODO: If we pass a non-existent app id we get an ugly error
        return 'org.gnome.Nautilus.desktop';
    }
    
    _getIcon(size) {
        return new St.Icon({
            gicon: this.gicon,
            icon_size: size
        });
    }

    getResultMetas(resultIds, callback) {
        try {
            let metas = [];
            
            for (let resultId of resultIds) {
                let result = this.resultsMap.get(resultId);
                
                metas.push({
                    'id': resultId,
                    'name': result.name,
                    'description': result.description,
                    'createIcon': this._getIcon.bind(result)
                });
            }
            
            callback(metas);
        } catch (e) {
            logError(e);
            callback([]);
        }
    }

    activateResult(uri) {
        try {
            let context = global.create_app_launch_context(0, -1);
            Gio.AppInfo.launch_default_for_uri_async(uri, context, null, null);
        } catch (e) {
            logError(e);
        }
    }
    
    _getFileInfo(file, cancellable = null) {
        return new Promise((resolve, reject) => {
            file.query_info_async(
                'standard::type,standard::display-name,standard::icon',
                Gio.FileQueryInfoFlags.NONE,
                GLib.PRIORITY_DEFAULT,
                cancellable,
                (file, res) => {
                    try {
                        resolve(file.query_info_finish(res));
                    } catch (e) {
                        if (!e.code || e.code !== Gio.IOErrorEnum.NOT_FOUND) {
                            reject(e);
                        }
                        
                        return null;
                    }
                }
            );
        });
    }

    async _getResultSet(cursor, callback, cancellable = null) {
        let resultIds = [];
        
        try {
            while (await this._getCursorNext(cursor)) {
                let uri = cursor.get_string(1)[0];
                //let parentUri = cursor.get_string(3)[0];
                
                let file = Gio.file_new_for_uri(uri);
                let info = await this._getFileInfo(file, cancellable);

                // If we didn't get and info, the file doesn't exist
                if (info === null) {
                    continue;
                }
                
                // Use the parent folder as the description
                let parent = file.get_parent().get_path();
                let description = parent.replace(GLib.get_home_dir(), '~');
                
                // Store the result metaInfo
                resultIds.push(uri);
                
                this.resultsMap.set(uri, {
                    'id': uri,
                    'name': info.get_display_name(),
                    'description': description,
                    'gicon': info.get_icon()
                });
            }
        } catch (e) {
            if (!e.code || e.code !== Gio.IOErrorEnum.CANCELLED) {
                logError(e);
            }
        } finally {
            callback(resultIds);
        }
    }
    
    _getConnection(cancellable = null) {
        return new Promise ((resolve, reject) => {
            // We've cached a connection already
            if (this._connection) {
                resolve();
                
            // Request a new SPARQL connection
            } else {
                Tracker.SparqlConnection.get_async(cancellable, (conn, res) => {
                    try {
                        this._connection = Tracker.SparqlConnection.get_finish(res);
                        resolve();
                    } catch (e) {
                        reject(e);
                    }
                });
            }
        });
    }

    _getQuery(terms, filetype = 'FileDataObject') {
        let query = '';
        
        // Add a wildcard (*) to each search term (except key-letters)
        let sparql = terms[0];
        
        if (sparql.length !== 1 || !['v', 'm', 'i'].includes(sparql)) {
            sparql += '*';
        }
        
        for (let i = 1; terms[i] !== undefined; i++) {
            sparql = `${sparql} ${terms[i]}*`;
        }
        
        // The tag should really be matched separately, not as one phrase
        query += 'SELECT ?urn nie:url(?urn) tracker:coalesce(nie:title(?urn), nfo:fileName(?urn)) nie:url(?parent) nfo:fileLastModified(?urn) WHERE { { ';
        query += ` ?urn a nfo:${filetype} .`;
        query += ` ?urn fts:match "${sparql}" } UNION { ?urn nao:hasTag ?tag . FILTER (fn:contains (fn:lower-case (nao:prefLabel(?tag)), "${terms}")) }`;
        query += ` OPTIONAL { ?urn nfo:belongsToContainer ?parent .  ?r2 a nfo:Folder . FILTER(?r2 = ?urn). } . FILTER(!BOUND(?r2)). } ORDER BY DESC(nfo:fileLastModified(?urn)) ASC(nie:title(?urn)) OFFSET 0 LIMIT ${MAX_RESULTS}`;
        // ?r2 a nfo:Folder . FILTER(?r2 = ?urn). } . FILTER(!BOUND(?r2) is
        // supposed to filter out folders, but this fails for 'root' folders
        // in which is indexed (as 'Music', 'Documents' and so on ..) - WHY?

        return query;
    }
    
    _getCursor(query, cancellable = null) {
        return new Promise((resolve, reject) => {
            this._connection.query_async(query, cancellable, (conn, res) => {
                try {
                    resolve(conn.query_finish(res));
                } catch (e) {
                    reject(e);
                }
            });
        });
    }
    
    _getCursorNext(cursor, cancellable = null) {
        return new Promise((resolve, reject) => {
            if (!cursor) {
                resolve(false);
            } else {
                cursor.next_async(cancellable, (cursor, res) => {
                    try {
                        resolve(cursor.next_finish(res));
                    } catch (e) {
                        resolve(false);
                    }
                });
            }
        });
    }
    
    async _search(terms, filetype, callback, cancellable = null) {
        try {
            await this._getConnection(cancellable);
            let query = this._getQuery(terms, filetype);
            let cursor = await this._getCursor(query, cancellable);
            
            await this._getResultSet(cursor, callback, cancellable);
        } catch (e) {
            if (!e.code || e.code !== Gio.IOErrorEnum.CANCELLED) {
                logError(e);
            }
        }
    }

    getInitialResultSet(terms, callback, cancellable = null) {
        try {
            let filetype;
            let firstTerm = terms[0];
            let termsLength = terms.length;
            
            // If we only have one search term and it's shorter than 3, we don't
            // have enough to search with. If we have two, but the second is
            // shorter than 3, we still don't have enough.
            if (termsLength === 1 && firstTerm.length < 3) {
                return [];
            }
            
            if (firstTerm.length === 1 && termsLength === 2 && terms[1].length < 3) {
                return [];
            }

            // Check for a key-letter: [m]usic, [i]mages, [v]ideos
            switch (true) {
                case (firstTerm.length > 1):
                    filetype = 'FileDataObject';
                    break;
                    
                case (firstTerm[0] === 'v'):
                    filetype = 'Video';
                    break;
                    
                case (firstTerm[0] === 'm'):
                    filetype = 'Audio';
                    break;
                    
                case (firstTerm[0] === 'i'):
                    filetype = 'Image';
                    break;
                    
                default:
                    filetype = 'FileDataObject';
            }
            
            this._search(terms, filetype, callback, cancellable);
        } catch (e) {
            logError(e);
        }
        
        return [];
    }

    getSubsearchResultSet(previousResults, terms, callback, cancellable) {
        // Ensure the first search term is > 2 letters
        if (terms.length === 1 && terms[0].length < 3) {
            return [];
        }
        
        this.getInitialResultSet(terms, callback, cancellable);
        
        return [];
    }

    filterResults(resultIds, max) {
        // TODO: could filter by last-modified or something?
        return resultIds.slice(0, max);
    }
}


/**
 * Extension Hooks
 */
let trackerSearchProvider = null;


function init() {
}


function enable() {
    if (haveTracker() && trackerSearchProvider === null) {
        trackerSearchProvider = new TrackerSearchProvider();
        
        // TODO: this is not available when the extension is loaded?
        //Main.overview.addSearchProvider(trackerSearchProvider);
        Main.overview.viewSelector._searchResults._registerProvider(
            trackerSearchProvider
        );
    }
}


function disable() {
    if (trackerSearchProvider !== null) {
        Main.overview.removeSearchProvider(trackerSearchProvider);
        
        trackerSearchProvider = null;
    }
}

